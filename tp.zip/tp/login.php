<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <!----------- ICONO TITULO ------------>
    <link rel="shortcut icon" href="images/logo_title2.ico" type="image/x-icon">
    <title>Shop.Ind</title>
    <link rel="stylesheet" href="css/stylesrecuperarpass.css">
  </head>
  <body>
        <!------------- lOGO SITIO ------------->
<a href="index.php" class="linkimg"><img src="images/logo.png" alt="" class="imagen_header"></a>
        <!------------- BUSCADOR -------------->
             <!-------------SLIDER  -----------------><br><br>
    <section class="bloque_central">
        <div class="registro">
          <h2>Inicar seción</h2>
          <h4>Inicia seción para comensar a comprar</h4>
            <label for="email">Email: </label><br>
            <input type="email" name="email" id="email" value=""><br>
            <label for="pas">Contraseña:</label><br>
            <input type="password" name="" value="" id="email"><br>
            <button type="submit" name="button">Enviar</button>
            <br><br>
            <input type="checkbox" name="" value="">
            <label for="pas">Recordar mi usuario</label><br>
            <p>No tenes usuario <a href="registro.php">Registrate</a> es gratis :).</p>
          </form>
        </div>
        </section>
        <br><br><br>        <!-------------FOOTER  ------------->
    <section class="bloque_footer">
        <div >
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="#">¿Quienes somos?</a></li>
            <li><a href="#">Contactanos</a></li>
            <li><a href="#">Ayuda</a></li>
          </ul>
          <ul>
            <li><a href="FAQS.html">FAQ´S</a></li>
            <li><a href="#">Reglas básicas</a></li>
          </ul>
          <ul>
            <li><a href="registro.php">Registrate</a></li>
            <li><a href="login.html">Ingresar</a></li>
          </ul>
        </div>
        <br><p>Copyright (c) 2017 Copyright Holder All Rights Reserved.</p>
    </section>

  </body>
</html>
