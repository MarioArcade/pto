<?php
$link = new mysqli('localhost','root','','registro');
  return $link
 ?>
